/*Stewart.h
 * Author J Waller 25/10/19
 * Library for Teensy Control of Stewart Platform
 * Adapted From: https://www.instructables.com/id/Stewart-Platform/
*/

#ifndef Stewart_h
#define Stewart_h

#include "Arduino.h"
#include "Servo.h"
struct Vector
{
	float x = 0;
	float y = 0;
	float z = 0;
};

class Stewart
{
	
	private:
		Vector translation, rotation, initialHeight;
		Vector baseJoint[6], platformJoint[6], q[6], l[6], A[6];
		float alpha[6];
		float baseRadius, platformRadius, hornLength, legLength;
		
		// base angles
		float baseAngles[6] = {
		  314.9, 345.1, 74.9, 105.1, 194.9, 225.1};
		
		// platform angles
		float platformAngles[6] = {
		  322.9, 337.1, 82.9, 97.1, 202.9, 217.1};
		
		// Angles between servo horns and x axis
		float beta[6] = {
		  -8*PI/3, PI/3, 0, -PI, -4*PI/3, -7*PI/3};
		  
		// Platform Measurements
		const float SCALE_INITIAL_HEIGHT = 120;
		const float SCALE_BASE_RADIUS = 70;
		const float SCALE_PLATFORM_RADIUS = 70;
		const float SCALE_HORN_LENGTH = 36;
		const float SCALE_LEG_LENGTH = 125;
		
		// Servos
		Servo Servos[6];
		void calcQ();
		void calcAlpha();
	public:
		Stewart(int servoPin[6]);
		void applyTranslationAndRotation(Vector translation, Vector rotation);
	
};
#endif

