/*Stewart.h
 * Author J Waller 25/10/19
 * Library for Teensy Control of Stewart Platform
 * Adapted From: https://www.instructables.com/id/Stewart-Platform/
*/

#include "Arduino.h"
#include "Stewart.h"

Stewart::Stewart(int pins[6])
{

  // platform initialisation
  initialHeight.z = SCALE_INITIAL_HEIGHT;
  baseRadius = SCALE_BASE_RADIUS;
  platformRadius = SCALE_PLATFORM_RADIUS;
  hornLength = SCALE_HORN_LENGTH;
  legLength = SCALE_LEG_LENGTH;

  for (int i=0; i<6; i++) {
      float mx = baseRadius*cos(radians(baseAngles[i]));
      float my = baseRadius*sin(radians(baseAngles[i]));
      baseJoint[i].x = mx;
      baseJoint[i].y = my;
  }

  for (int i=0; i<6; i++) {
     float mx = platformRadius*cos(radians(platformAngles[i]));
     float my = platformRadius*sin(radians(platformAngles[i]));

     platformJoint[i].x = mx;
     platformJoint[i].y = my;

  }
  calcQ();

  // Servo Initialisation
  for(int i = 0; i < 6; i++)
  {
	  Servos[i].attach(pins[i]);
  }
}


// Function to Apply Translation and Rotation Vectors to Platform
void Stewart::applyTranslationAndRotation(Vector t, Vector r)
{
  translation.x = t.x;
  translation.y = t.y;
  translation.z = t.z;

  rotation.x = r.x;
  rotation.y = r.y;
  rotation.z = r.z;

  calcQ();
  calcAlpha();

  // Write values to servos
  for(int i = 0; i < 6; i++)
  {
    if(isnan(alpha[i]))
      continue;

    if(i%2 == 0)
      Servos[i].write(90-degrees(alpha[i]));
    else
      Servos[i].write(90+degrees(alpha[i]));
  }
}


void Stewart::calcQ()
{
  for(int i = 0; i < 6; i++)
  {
    // rotation
    q[i].x = cos(rotation.z)*cos(rotation.y)*platformJoint[i].x +
        (-sin(rotation.z)*cos(rotation.x)+cos(rotation.z)*sin(rotation.y)*sin(rotation.x))*platformJoint[i].y +
        (sin(rotation.z)*sin(rotation.x)+cos(rotation.z)*sin(rotation.y)*cos(rotation.x))*platformJoint[i].z;
    
    q[i].y = sin(rotation.z)*cos(rotation.y)*platformJoint[i].x +
        (cos(rotation.z)*cos(rotation.x)+sin(rotation.z)*sin(rotation.y)*sin(rotation.x))*platformJoint[i].y +
        (-cos(rotation.z)*sin(rotation.x)+sin(rotation.z)*sin(rotation.y)*cos(rotation.x))*platformJoint[i].z;

    q[i].z = -sin(rotation.y)*platformJoint[i].x +
        cos(rotation.y)*sin(rotation.x)*platformJoint[i].y +
        cos(rotation.y)*cos(rotation.x)*platformJoint[i].z;
    
    // translation
    q[i].x += translation.x + initialHeight.x;
    q[i].y += translation.y + initialHeight.y;
    q[i].z += translation.z + initialHeight.z;

    l[i].x = q[i].x - baseJoint[i].x;
    l[i].y = q[i].y - baseJoint[i].y;
    l[i].z = q[i].z - baseJoint[i].z;
  }  
}

void Stewart::calcAlpha()
{
  for (int i=0; i<6; i++) {

      float magSqL = (l[i].x*l[i].x) + (l[i].y*l[i].y) + (l[i].z*l[i].z);
      
      float L = magSqL-(legLength*legLength)+(hornLength*hornLength);
      float M = 2*hornLength*(q[i].z-baseJoint[i].z);
      float N = 2*hornLength*(cos(beta[i])*(q[i].x-baseJoint[i].x) + sin(beta[i])*(q[i].y-baseJoint[i].y));
      alpha[i] = asin(L/sqrt(M*M+N*N)) - atan2(N, M);
      alpha[i] = constrain(alpha[i], -PI/2, PI/2);
      
      A[i].x = hornLength*cos(alpha[i])*cos(beta[i]) + baseJoint[i].x; 
      A[i].y = hornLength*cos(alpha[i])*sin(beta[i]) + baseJoint[i].y; 
      A[i].z = hornLength*sin(alpha[i]) + baseJoint[i].z;

      float xqxb = (q[i].x-baseJoint[i].x);
      float yqyb = (q[i].y-baseJoint[i].y);
      float h0 = sqrt((legLength*legLength)+(hornLength*hornLength)-(xqxb*xqxb)-(yqyb*yqyb)) - q[i].z;

      float L0 = 2*hornLength*hornLength;
      float M0 = 2*hornLength*(h0+q[i].z);
      float a0 = asin(L0/sqrt(M0*M0+N*N)) - atan2(N, M0);

      //println(i+":"+alpha[i]+"  h0:"+h0+"  a0:"+a0);
  }
}
