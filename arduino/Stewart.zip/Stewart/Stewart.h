/*Stewart.h
 * Author J Waller 25/10/19
 * Library for Teensy Control of Stewart Platform
 * Adapted From: https://www.instructables.com/id/Stewart-Platform/
*/

#ifndef Stewart_h
#define Stewart_h

#include "Arduino.h"
#include "Servo.h"
struct Vector
{
	float x = 0;
	float y = 0;
	float z = 0;
};

class Stewart
{
	
	private:
		// Vectors for Platform location and orientation
		Vector translation, rotation, initialHeight;
		// Vectors used in inverse kinematic calculations
		Vector baseJoint[6], platformJoint[6], q[6], l[6], A[6];
		// Array containing servo angles
		float alpha[6];
		// Dimensions of platform
		float baseRadius, platformRadius, hornLength, legLength;
		
		// base angles
		float baseAngles[6] = {
		  319, 341, 79, 101, 199, 221};
		
		// platform angles
		float platformAngles[6] = {
		  319, 341, 79, 101, 199, 221};
		
		// Angles between servo horns and x axis
		float beta[6] = {
		  -8*PI/3, PI/3, 0, -PI, -4*PI/3, -7*PI/3};
		  
		// Platform Measurements
		const float SCALE_INITIAL_HEIGHT = 125;
		const float SCALE_BASE_RADIUS = 55;
		const float SCALE_PLATFORM_RADIUS = 52.5;
		const float SCALE_HORN_LENGTH = 16;
		const float SCALE_LEG_LENGTH = 126.4;
		
		// Servos
		Servo Servos[6];
		// Function to calculate stewart platform rod lengths given a translation and rotation
		void calcQ();
		// Function to calculate servo angles for given rod lengths
		void calcAlpha();
	public:
		Stewart(int servoPin[6]);
		void applyTranslationAndRotation(Vector translation, Vector rotation);
	
};
#endif

